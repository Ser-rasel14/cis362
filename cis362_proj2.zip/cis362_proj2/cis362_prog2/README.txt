cis362_prog2.zip
kbyron@bmcc.cuny.edu
2-10-2022

The CIS362 Info Center application is launched by running the index.php file.
Components of the zip file are the following:
 - bengals_pic.png - sample image
 - bruins_pic.png - sample image
 - Calculation.php: arithmetic operands prompt page
 - handle_calculation.php: arithmetic results display page
 - index.php: home page and arithmetic operand gathering page 
 - islanders_pic.png - sample image
 - news.php: current news display page
 - rams_pic.jpg - sample image
 - rangers_pic.png - sample image
 - README.txt - this file
 - weather.php - current weather display page

